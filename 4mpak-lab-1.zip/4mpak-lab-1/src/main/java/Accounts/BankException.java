package Accounts;

public class BankException extends Exception {
    public BankException(String exception) {
        super(exception);
    }
}